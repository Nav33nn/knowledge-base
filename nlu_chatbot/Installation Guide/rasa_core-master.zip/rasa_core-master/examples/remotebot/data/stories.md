## greet
* greet
    - greet

## happy
* thankyou
    - youarewelcome

## goodbye
* goodbye
    - goodbye

## venue_search
* search_venues
    - search_venues
    - slot{"venues": [{"name": "Big Arena", "reviews": 4.5}]}

## concert_search
* search_concerts
    - search_concerts
    - slot{"concerts": [{"artist": "Foo Fighters", "reviews": 4.5}]}

## compare_reviews_venues
* compare_reviews
    - show_venue_reviews

## compare_reviews_concerts
* compare_reviews
    - show_concert_reviews
