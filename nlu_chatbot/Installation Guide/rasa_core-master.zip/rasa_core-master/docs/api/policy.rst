Policy
======

A Policy decides what action to take at every step in a dialogue



.. autoclass:: rasa_core.policies.Policy

   .. automethod:: featurize_for_training

   .. automethod:: train

   .. automethod:: predict_action_probabilities

