## story_00914561
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* thankyou
 - utter_goodbye

## story_03812903
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "six", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* thankyou
 - utter_goodbye

## story_00055028
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* thankyou
 - utter_goodbye

## story_04649138
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* thankyou
 - utter_goodbye

## story_00832024
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "london", "price": "expensive"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* thankyou
 - utter_goodbye

## story_07265875
* greet
 - utter_ask_howcanhelp
* inform{"people": "two", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* thankyou
 - utter_goodbye

## story_02879216
* greet
 - utter_ask_howcanhelp
* inform{"people": "two", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* thankyou
 - utter_goodbye

## story_04818543
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "madrid", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* thankyou
 - utter_goodbye
