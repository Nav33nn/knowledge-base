<!-- THIS INFORMATION IS MANDATORY - YOUR ISSUE WILL BE CLOSED IF IT IS MISSING. If you don't know your Rasa Core version, use `pip list | grep rasa_core`. Removing the below information is allowed for FEATURE REQUESTS. --> 

**Rasa Core version**:

**Python version**: 

**Operating system** (windows, osx, ...):

**Issue**:



**Content of domain file** (if used & relevant):
```yaml

```
