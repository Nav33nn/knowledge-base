## Generated Story -1519135848831195187
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "delhi"}
    - slot{"location": "delhi"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - utter_ask_price_range
* price_check{"range": "more"}
    - slot{"range": "more"}
    - action_search_restaurants
    - slot{"location": "delhi"}
    - utter_email_send_confirmation
* affirm
    - utter_ask_email_id
* send_email{"email": "nav33nn92@gmail.com"}
    - slot{"email": "nav33nn92@gmail.com"}
    - action_send_email
    - slot{"location": "delhi"}
* goodbye
    - utter_goodbye
    - action_restart

## Generated Story -6850782606357078389
* greet
    - utter_greet
* restaurant_search{"location": "kolkata"}
    - slot{"location": "kolkata"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price_range
* price_check{"range": "more"}
    - slot{"range": "more"}
    - action_search_restaurants
    - slot{"location": "kolkata"}
    - utter_email_send_confirmation
* affirm
    - utter_ask_email_id
* send_email{"email": "nav33nn92@gmail.com"}
    - slot{"email": "nav33nn92@gmail.com"}
    - action_send_email
    - slot{"location": "delhi"}
* goodbye
    - utter_goodbye
    - action_restart

## Generated Story -8053410175383260843
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "mumbai"}
    - slot{"location": "mumbai"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - utter_ask_price_range
* price_check{"range": "more"}
    - slot{"range": "more"}
    - action_search_restaurants
    - slot{"location": "mumbai"}
    - utter_email_send_confirmation
* affirm
    - utter_ask_email_id
* send_email{"email": "nav33nn92@gmail.com"}
    - slot{"email": "nav33nn92@gmail.com"}
    - action_send_email
    - slot{"location": "mumbai"}
    - utter_goodbye
    - action_restart

## Generated Story 46504577350922237
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"cuisine": "chinese", "location": "chandigarh"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "chandigarh"}
    - utter_ask_price_range
* price_check{"range": "more"}
    - slot{"range": "more"}
    - action_search_restaurants
    - slot{"location": "chandigarh"}
    - utter_email_send_confirmation
* affirm
    - utter_ask_email_id
* send_email{"email": "nav33nn92@gmail.com"}
    - slot{"email": "nav33nn92@gmail.com"}
    - action_send_email
    - slot{"location": "delhi"}
* goodbye
    - utter_goodbye
    - action_restart

## Generated Story -7918230797685511971
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "abcdefg"}
    - slot{"location": "abcdefg"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price_range
* price_check{"range": "more"}
    - slot{"range": "more"}
    - action_search_restaurants
    - utter_email_send_confirmation
* affirm
    - utter_ask_email_id
* send_email{"email": "nav33nn92@gmail.com"}
    - slot{"email": "nav33nn92@gmail.com"}
    - utter_goodbye
    - action_restart

## Generated Story -1519135848831195187
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "delhi"}
    - slot{"location": "delhi"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - utter_ask_price_range
* price_check{"range": "more"}
    - slot{"range": "more"}
    - action_search_restaurants
    - slot{"location": "delhi"}
    - utter_email_send_confirmation
* affirm
    - utter_ask_email_id
* send_email{"email": "nav33nn92@gmail.com"}
    - slot{"email": "nav33nn92@gmail.com"}
    - action_send_email
    - slot{"location": "delhi"}
* goodbye
    - utter_goodbye
    - action_restart


## Generated Story -4639179087166749998
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "delhi"}
    - slot{"location": "delhi"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price_range
* price_check{"range": "between"}
    - slot{"range": "between"}
    - action_search_restaurants
    - slot{"location": "delhi"}
    - utter_email_send_confirmation
* affirm
    - utter_ask_email_id
* send_email{"email": "abc@abc.com"}
    - slot{"email": "abc@abc.com"}
    - action_send_email
* goodbye
    - utter_goodbye
    - action_restart


## Generated Story 4963448062290237512
* greet
    - utter_greet
* restaurant_search{"location": "delhi"}
    - slot{"location": "delhi"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price_range
* price_check{"range": "between"}
    - slot{"range": "between"}
    - action_search_restaurants
    - utter_email_send_confirmation
* affirm
    - utter_ask_email_id
* send_email{"email": "abc@abc.com"}
    - slot{"email": "abc@abc.com"}
    - action_send_email
* goodbye
    - utter_goodbye
    - action_restart

## Generated Story -1371393708137348274
* greet
    - utter_greet
* restaurant_search{"cuisine": "italian", "location": "bangalore"}
    - slot{"cuisine": "italian"}
    - slot{"location": "bangalore"}
    - utter_ask_price_range
* price_check{"range": "between"}
    - slot{"range": "between"}
    - action_search_restaurants
    - slot{"location": "bangalore"}
    - utter_email_send_confirmation
* affirm
    - utter_ask_email_id
* send_email{"email": "reghuram.rv@gmail.com"}
    - slot{"email": "reghuram.rv@gmail.com"}
    - action_send_email
* goodbye
    - utter_goodbye
    - action_restart


## Generated Story 8104540199928037149
* greet
    - utter_greet
* restaurant_search{"cuisine": "italian"}
    - slot{"cuisine": "italian"}
    - utter_ask_location
* restaurant_search{"location": "chennai"}
    - slot{"location": "chennai"}
    - utter_ask_price_range
* price_check{"range": "-"}
    - slot{"range": "between"}
    - action_search_restaurants
    - slot{"location": "chennai"}
    - utter_email_send_confirmation
* affirm
    - utter_ask_email_id
* send_email{"email": "reghuram.rv@gmail.com"}
    - slot{"email": "reghuram.rv@gmail.com"}
* goodbye
    - utter_goodbye
    - action_restart
    
    

## Generated Story -4788423261798420954
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "bangalore"}
    - slot{"location": "bangalore"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "mexican"}
    - slot{"cuisine": "mexican"}
    - utter_ask_price_range
* price_check{"range": "more"}
    - slot{"range": "more"}
    - action_search_restaurants
    - slot{"location": "bangalore"}
    - utter_email_send_confirmation
* affirm
    - utter_ask_email_id
* send_email{"email": "dipesh.singhal@gmail.com"}
    - slot{"email": "dipesh.singhal@gmail.com"}
    - action_send_email
* goodbye
    - utter_goodbye
    - action_restart


## Generated Story -8544261640449368810
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "chennai"}
    - slot{"location": "chennai"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "italian"}
    - slot{"cuisine": "italian"}
    - utter_ask_price_range
* price_check{"range": "more"}
    - slot{"range": "more"}
    - action_search_restaurants
    - slot{"location": "chennai"}
    - utter_email_send_confirmation
* affirm
    - utter_ask_email_id
* send_email{"email": "nav33nn92@gmail.com"}
    - slot{"email": "nav33nn92@gmail.com"}
    - action_send_email
    - slot{"location": "chennai"}
* goodbye
    - utter_goodbye
    - action_restart

## Generated Story 1790907978690551297
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "bangalore"}
    - slot{"location": "bangalore"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price_range
* price_check{"range": "between"}
    - slot{"range": "between"}
    - action_search_restaurants
    - slot{"location": "bangalore"}
    - utter_email_send_confirmation
* affirm
    - utter_ask_email_id
* send_email{"email": "sanjay.7183@gmail.com"}
    - slot{"email": "sanjay.7183@gmail.com"}
    - action_send_email
    - slot{"location": "bangalore"}
* goodbye
    - utter_goodbye
    - action_restart

## Generated Story 5597836606031862630
* greet
    - utter_greet
* restaurant_search{"location": "rishikesh"}
    - slot{"location": "rishikesh"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - action_search_restaurants
    - slot{"location": "rishikesh"}
    - utter_ask_howcanhelp
* restaurant_search{"location": "allahabad"}
    - slot{"location": "allahabad"}
    - action_search_restaurants
    - slot{"location": "allahabad"}
    - utter_ask_email_id
    - utter_email_send_confirmation
* send_email{"email": "sanjay.7183@gmail.com"}
    - slot{"email": "sanjay.7183@gmail.com"}
    - action_send_email
    - slot{"location": "allahabad"}
* goodbye
    - utter_goodbye
    - action_restart

## Generated Story 2757312373372637232
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "mumbai"}
    - slot{"location": "mumbai"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "american"}
    - slot{"cuisine": "american"}
    - utter_ask_price_range
* price_check{"range": "less"}
    - slot{"range": "less"}
    - action_search_restaurants
    - slot{"location": "mumbai"}
    - utter_email_send_confirmation
* send_email{"email": "sanjay.7183@gmail.com"}
    - slot{"email": "sanjay.7183@gmail.com"}
* goodbye
    - utter_goodbye
    - action_restart

## Generated Story -7918230797685511971
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "abcdefg"}
    - slot{"location": "abcdefg"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price_range
* price_check{"range": "more"}
    - slot{"range": "more"}
    - action_search_restaurants
    - utter_email_send_confirmation
* affirm
    - utter_ask_email_id
* send_email{"email": "nav33nn92@gmail.com"}
    - slot{"email": "nav33nn92@gmail.com"}
    - utter_goodbye
    - action_restart